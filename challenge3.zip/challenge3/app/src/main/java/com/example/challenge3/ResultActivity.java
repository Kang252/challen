package com.example.challenge3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        TextView tvResultMessage = findViewById(R.id.tvResultMessage);
        TextView tvFinalScore = findViewById(R.id.tvFinalScore);
        Button btnPlayAgain = findViewById(R.id.btnPlayAgain);
        Button btnExit = findViewById(R.id.btnExit);

        int finalScore = getIntent().getIntExtra("FINAL_SCORE", 0);
        tvFinalScore.setText("Score: " + finalScore);
        tvResultMessage.setText("Congratulation");

        btnPlayAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ResultActivity.this, MainMenuActivity.class);
                startActivity(intent);
                finish();
            }
        });

        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
            }
        });
    }
}