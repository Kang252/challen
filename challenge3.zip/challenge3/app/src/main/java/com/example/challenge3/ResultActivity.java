package com.example.challenge3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        // Khởi tạo các view
        TextView tvResultMessage = findViewById(R.id.tvResultMessage);
        TextView tvFinalScore = findViewById(R.id.tvFinalScore);
        Button btnPlayAgain = findViewById(R.id.btnPlayAgain);
        Button btnExit = findViewById(R.id.btnExit);

        // Lấy điểm số từ Intent
        int finalScore = getIntent().getIntExtra("FINAL_SCORE", 0);
        tvFinalScore.setText(String.format(getString(R.string.final_score), finalScore));

        // Thiết lập thông điệp chúc mừng
        tvResultMessage.setText(finalScore >= 50 ? getString(R.string.excellent) : getString(R.string.congratulations));

        // Xử lý nút Chơi lại
        btnPlayAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ResultActivity.this, MainMenuActivity.class);
                startActivity(intent);
                finish();
            }
        });

        // Xử lý nút Thoát
        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity(); // Đóng ứng dụng
            }
        });
    }
}