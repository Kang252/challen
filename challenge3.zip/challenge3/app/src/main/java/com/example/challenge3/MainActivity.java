package com.example.challenge3;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private TextView tvLives, tvTimer, tvScore, tvQuestion;
    private EditText etAnswer;
    private Button btnSubmit;
    private int lives = 3;
    private int score = 0;
    private int correctAnswer;
    private CountDownTimer timer;
    private long timeLeft = 60000; // 60 giây
    private String currentOperation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Khởi tạo các view
        tvLives = findViewById(R.id.tvLives);
        tvTimer = findViewById(R.id.tvTimer);
        tvScore = findViewById(R.id.tvScore);
        tvQuestion = findViewById(R.id.tvQuestion);
        etAnswer = findViewById(R.id.etAnswer);
        btnSubmit = findViewById(R.id.btnSubmit);

        // Lấy loại phép toán từ Intent
        currentOperation = getIntent().getStringExtra("OPERATION");
        if (currentOperation == null) currentOperation = "addition";

        // Bắt đầu trò chơi
        startGame();

        // Xử lý nút Gửi
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer();
            }
        });
    }

    private void startGame() {
        lives = 3;
        score = 0;
        timeLeft = 60000;
        updateUI();
        generateQuestion();
        startTimer();
    }

    private void generateQuestion() {
        Random random = new Random();
        int num1 = random.nextInt(50) + 1;
        int num2 = random.nextInt(50) + 1;
        switch (currentOperation) {
            case "addition":
                correctAnswer = num1 + num2;
                tvQuestion.setText(String.format(getString(R.string.question_format), num1, num2));
                break;
            case "subtraction":
                correctAnswer = num1 - num2;
                tvQuestion.setText(String.format(getString(R.string.question_format_subtraction), num1, num2));
                break;
            case "multiplication":
                correctAnswer = num1 * num2;
                tvQuestion.setText(String.format(getString(R.string.question_format_multiplication), num1, num2));
                break;
            case "division":
                num2 = num1; // Đảm bảo chia hết
                correctAnswer = num1 / num2;
                tvQuestion.setText(String.format(getString(R.string.question_format_division), num1, num2));
                break;
        }
        etAnswer.setText("");
    }

    private void startTimer() {
        if (timer != null) {
            timer.cancel();
        }
        timer = new CountDownTimer(timeLeft, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timeLeft = millisUntilFinished;
                tvTimer.setText(String.format(getString(R.string.timer), timeLeft / 1000));
            }

            @Override
            public void onFinish() {
                endGame();
            }
        }.start();
    }

    private void checkAnswer() {
        String userAnswerStr = etAnswer.getText().toString();
        try {
            int userAnswer = Integer.parseInt(userAnswerStr);
            if (userAnswer == correctAnswer) {
                score += 10;
                generateQuestion();
            } else {
                lives--;
                if (lives == 0) {
                    endGame();
                } else {
                    generateQuestion();
                }
            }
            updateUI();
        } catch (NumberFormatException e) {
            generateQuestion();
        }
    }

    private void updateUI() {
        tvLives.setText(String.format(getString(R.string.lives), lives));
        tvScore.setText(String.format(getString(R.string.score), score));
    }

    private void endGame() {
        if (timer != null) {
            timer.cancel();
        }
        Intent intent = new Intent(MainActivity.this, ResultActivity.class);
        intent.putExtra("FINAL_SCORE", score);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        if (timer != null) {
            timer.cancel();
        }
        super.onDestroy();
    }
}